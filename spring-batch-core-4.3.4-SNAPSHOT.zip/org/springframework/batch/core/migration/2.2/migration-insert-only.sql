
-- insert script that 'copies' existing batch_job_params to batch_job_execution_params
-- sets new params to identifying ones
-- verified on h2, 

INSERT INTO BATCH_JOB_EXECUTION_PARAMS 
	( JOB_EXECUTION_ID , TYPE_CD, KEY_NAME, STRING_VAL, DATE_VAL, LONG_VAL, DOUBLE_VAL, IDENTIFYING )
SELECT 
	JE.JOB_EXECUTION_ID , JP.TYPE_CD , JP.KEY_NAME , JP.STRING_VAL , JP.DATE_VAL , JP.LONG_VAL , JP.DOUBLE_VAL , 'Y' 
FROM 
	BATCH_JOB_PARAMS JP,BATCH_JOB_EXECUTION JE
WHERE 
	JP.JOB_INSTANCE_ID = JE.JOB_INSTANCE_ID;